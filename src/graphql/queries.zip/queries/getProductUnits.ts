import { gql } from "@apollo/client";

export const GetProductUnits = gql`
query GetProductUnits {
  getProductUnits {
    id
    name
  }
}

`;