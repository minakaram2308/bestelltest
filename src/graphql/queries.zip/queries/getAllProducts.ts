
import { gql } from "@apollo/client";

export const GetAllProducts = gql`
query GetAllProducts($pageNo: Int = 0, $pageSize: Int = 100) {
  getAllProducts(pageNo: $pageNo, pageSize: $pageSize) {
    id
    title
    price
    image
  }
}

`;