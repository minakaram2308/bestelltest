
import { gql } from "@apollo/client";

export const GetProducts = gql`
query GetProducts(
  $category: Category!
  $subCategoryId: Int
  $searchWord: String
  $filterBy: ProductFilter = ALL
  $sortBy: ProductSort
  $pageNo: Int = 0
  $pageSize: Int = 100
) {
  getProducts(
    category: $category
    subCategoryId: $subCategoryId
    searchWord: $searchWord
    filterBy: $filterBy
    sortBy: $sortBy
    pageNo: $pageNo
    pageSize: $pageSize
  ) {
    id
    title
    price
    image
  }
}

`;