
  import { gql } from "@apollo/client";

export const ARCHIVE_PRODUCT = gql`
mutation ArchiveProduct($productId: ID!) {
    archiveProduct(productId: $productId)
  }
`;
